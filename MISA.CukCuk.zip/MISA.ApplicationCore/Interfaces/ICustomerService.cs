﻿using MISA.ApplicationCore.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.ApplicationCore.Interfaces
{
    /// <summary>
    /// Customer service
    /// </summary>
    /// <seealso cref="MISA.Infrastructure.BaseRepository{MISA.Entity.Models.Customer}" />
    /// <seealso cref="MISA.Infrastructure.Interfaces.ICustomerRepository" />
    /// createdBy: dtkien1 (14/12/2020)
    public interface ICustomerService : IBaseService<Customer>
    {
        /// <summary>
        /// Lấy danh sách khách hàng theo nhóm khách hàng
        /// </summary>
        /// <param name="groupId">Id nhóm khách hàng</param>
        /// <returns>List khách hàng</returns>
        /// CreatedBy: NVMANH (26/11/2020)
        IEnumerable<Customer> GetCustomersByGroup(Guid groupId);
        IEnumerable<Customer> GetEntityPaging(int pageSize, int pageIndex, string searchKey, Guid? customerGroupId);
        int GetCountCondition(string searchKey, Guid? customerGroupId);
    }
}
