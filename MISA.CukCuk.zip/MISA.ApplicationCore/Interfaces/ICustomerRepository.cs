﻿using MISA.ApplicationCore.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.ApplicationCore.Interfaces
{
    public interface ICustomerRepository : IBaseRepository<Customer>
    {
        /// <summary>
        /// Lấy dữ liệu khách hàng theo mã khách hàng
        /// </summary>
        /// <param name="customerCode">Mã khách hàng.</param>
        /// <returns>Khách hàng có mã tương ứng</returns>
        Customer GetCustomerByCode(string customerCode);
        IEnumerable<Customer> GetEntityPaging(int limit, int offset, string searchKey, Guid? customerGroupId);
        int GetCountCondition(string searchKey, Guid? customerGroupId);
    }
}
