﻿using System;

namespace MISA.Application
{
    public class Class1
    {
    }
}
